----------------------------------------
GDP02 - Cloth Simulation - Alex Denford   
----------------------------------------
 14/11/2014
----------
Overview:
----------
Cloth simulation using C++, verlet integration and DirectX 10.  
This physics project demonstrates a mass spring system using verlet integration.


----------
Features:
----------
Mouse interaction, burning, ripping.
Collision with objects & floor
Fan & wind system
FPS style camera


----------
Controls:
---------
WASD 			-	Camera movement
SPACE / LSHIFT		- 	Move up / down
Mouse move		- 	First person camera look


Left Control		- 	Toggle switch to free selection mode (using mouse)
Mouse 1			- 	Interact with cloth or GUI buttons
Mouse 2			- 	Cut cloth 
Mouse 3 (middle mouse)	- 	Burn cloth

R 			-	Hard reset (resets entire simulation + variables)

1 			-	Select Sphere object
2			- 	Select Pyramid object
3			- 	Select Capsule object
4			- 	Select Fan object

Arrow keys		- 	Move selected object
PGUP / PGDWN		- 	Move selected object up / down

- (Minus)		- 	Close rods (move closer together)
+ (Plus)		- 	Open rods (move further apart)



---------------------------------
Created by Alex Denford for MDS
17/10/2014 - 14/11/2014
Media Design School (2014)
---------------------------------